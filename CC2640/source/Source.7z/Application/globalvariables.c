//#include <stdint.h>
//#include "stdio.h"
//#include "_Parameter.h"
//#include "Defines.h"
//#include "globalvariables.h"
//#include "ATcontrol.h"
//#include "BatteryPowerCal.h"
//#include "Guard.h"
//#include "Onelinecommunica.h"
#include "CustomerPara.h"

/*************************************************/
/*******************Variable**********************/
/****************timer in systemstick*************/
volatile uint8_t timer_2ms_per100us = 0 ;
uint8_t timer_500ms_per2ms = 0 ;
//volatile uint8_t timer_100us = 0 ;
//volatile uint16_t timer_200msForBLE_per100us = 0 ;
volatile uint16_t timer_100ms_per100us = 0 ;
volatile uint16_t timer_1s_per100us = 0 ;





