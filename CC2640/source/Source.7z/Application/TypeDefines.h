#ifndef __TYPEDEFINES_H
#define __TYPEDEFINES_H
#include "stdint.h"

/**********************Buzzer************************/
#define 	Ring1_Mul2							(1*2)
#define		Ring2_Mul2							(2*2)
#define		Ring5_Mul2							(5*2)
#define		Timer_AddCounter_Per2ms				75			//75*2ms =150ms



#endif
